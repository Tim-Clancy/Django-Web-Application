from django.shortcuts import render
from student.models import Student, StudentCourse
from courses.models import Courses
from modules.models import Modules
from djangoproject.decorators import allowed
from djangoproject.filters import StudentFilter
from djangoproject.forms import addCourse
from .models import Teacher

@allowed(allowed_roles=['Teachers'])
def adminPortal(request):
    student3 = Student.objects.all()
    student2 = Student.objects.all()
    courses = Courses.objects.all()
    modules = Modules.objects.all()
    sc = StudentCourse.objects.all()
    current = request.user

    std = Teacher.objects.get(email=current)
    name = std.fname + ' ' + std.lname
    email = std.email

    myFilter = StudentFilter(request.GET, queryset=student3)
    student = myFilter.qs

    form = addCourse()
    if request.method == 'POST':
        form = addCourse(request.POST)
        if form.is_valid():
            stdname = form.cleaned_data['name']
            module = form.cleaned_data['module']
            stdcrs = StudentCourse(student=stdname, course=module)
            stdcrs.save()
    return render(request, 'teacher/adminportal.html', {
    'student': student,
    'student2': student2,
    'modules': modules,
    'myFilter': myFilter,
    'form': form,
    'sc': sc,
    'name': name,
    'email': email
    })
