from django.contrib import admin
from .models import Modules

admin.site.register(Modules)
