from django.db import models
from teacher.models import Teacher

class Modules(models.Model):
    title = models.CharField(max_length=100)
    teacherID = models.ForeignKey(Teacher, on_delete=models.CASCADE)
    progress = models.CharField(max_length=100)
    grade = models.CharField(max_length=100)

    def __str__(self):
        return self.title
