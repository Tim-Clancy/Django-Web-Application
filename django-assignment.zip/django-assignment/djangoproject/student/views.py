from django.shortcuts import render
from .models import Student, StudentCourse
from courses.models import Courses
from modules.models import Modules
from djangoproject.decorators import allowed

@allowed(allowed_roles=['Students'])
def studentPortal(request):
    sc = StudentCourse.objects.all()
    current = request.user
    std = Student.objects.get(email=current)
    stdcrs = StudentCourse.objects.filter(student=std).all()
    name = std.fname + ' ' + std.lname
    email = std.email
    course = std.course
    return render(request, 'student/studentportal.html', {
    'name': name,
    'email': email,
    'course': course,
    'crs': stdcrs
    })
