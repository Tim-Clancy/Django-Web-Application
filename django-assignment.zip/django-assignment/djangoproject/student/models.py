from django.db import models
from courses.models import Courses

class Student(models.Model):
    fname = models.CharField(max_length=100)
    lname = models.CharField(max_length=100)
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    course = models.ForeignKey(Courses, default=1, on_delete=models.CASCADE)

    def __str__(self):
        return self.fname

class StudentCourse(models.Model):
    student = models.CharField(max_length=100)
    course = models.CharField(max_length=100)
    progress = models.CharField(default='0', max_length=100)

    def __str__(self):
        return self.student
