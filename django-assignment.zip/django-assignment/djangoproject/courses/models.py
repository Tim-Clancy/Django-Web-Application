from django.db import models
from modules.models import Modules

class Courses(models.Model):
    title = models.CharField(max_length=100)
    module = models.ForeignKey(Modules, on_delete=models.CASCADE)

    def __str__(self):
        return self.title
