from django.contrib import admin
from .models import Courses

admin.site.register(Courses)
