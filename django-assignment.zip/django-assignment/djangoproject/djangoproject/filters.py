import django_filters
from django_filters import DateFilter
from student.models import Student

class StudentFilter(django_filters.FilterSet):
    class Meta:
        model = Student
        fields = '__all__'
        exclude = ['course', 'password', 'email', 'lname']
