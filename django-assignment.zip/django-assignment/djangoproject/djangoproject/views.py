from django.http import HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, logout
from .forms import SignUpForm
from modules.models import Modules
from django.contrib.auth.models import Group
from .decorators import nonauthenticated
from student.models import Student, StudentCourse
from djangoproject.filters import StudentFilter
from teacher.models import Teacher
from djangoproject.decorators import allowed

def home(request):
    return render(request, 'homepage.html')

def signUp(request):
    form = SignUpForm()
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            g = Group.objects.get(name = 'Students')
            user.groups.add(g)
            username = form.cleaned_data['username']
            fname = form.cleaned_data['fname']
            lname = form.cleaned_data['lname']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password2']
            std = Student(fname=fname, lname=lname, email=email, password=password)
            std.save()
            return redirect('/')
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form})

def likert(request):

    return render(request, 'likert.html')

@nonauthenticated
def studentLogin(request):
        form = AuthenticationForm()
        if request.method == 'POST':
            form = AuthenticationForm(data=request.POST)
            if form.is_valid():
                user = form.get_user()
                login(request, user)
                return redirect('/studentportal/')
        else:
            form = AuthenticationForm()
        return render(request, 'studentlogin.html', {'form': form})

@nonauthenticated
def adminLogin(request):
    form = AuthenticationForm()
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('/adminportal/')
    else:
        form = AuthenticationForm()
    return render(request, 'adminlogin.html',  {'form': form})


def logout_user(request):
    if request.method == 'POST':
        logout(request)
        return redirect('/')

@allowed(allowed_roles=['Teachers'])
def generateReportForm(request):
    student3 = Student.objects.all()
    student2 = Student.objects.all()
    modules = Modules.objects.all()
    current = request.user
    sc = StudentCourse.objects.all()
    std = Teacher.objects.get(email=current)
    myFilter = StudentFilter(request.GET, queryset=student3)
    student = myFilter.qs
    name = std.fname + ' ' + std.lname
    email = std.email
    stdcrs = None
    if request.method == 'POST':
        stdcrs = StudentCourse.objects.filter(student=student[0])
    return render(request, 'teacher/generatereportform.html', {
    'student': student,
    'student2': student2,
    'modules': modules,
    'myFilter': myFilter,
    'sc': sc,
    'name': name,
    'email': email,
    'stdcrs': stdcrs
    })
