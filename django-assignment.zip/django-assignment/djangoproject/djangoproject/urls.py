from django.conf.urls import url, include
from django.contrib import admin
from django.urls import path
from . import views
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.home),
    path('studentlogin/', views.studentLogin),
    path('adminlogin/', views.adminLogin),
    path('adminportal/', include('teacher.urls')),
    path('generatereportform/', views.generateReportForm),
    path('studentportal/', include('student.urls')),
    path('signup/', views.signUp),
    path('courses/', include('courses.urls')),
    path('likert/', views.likert),
    url('logout', views.logout_user, name='logout')
]

urlpatterns += staticfiles_urlpatterns()
