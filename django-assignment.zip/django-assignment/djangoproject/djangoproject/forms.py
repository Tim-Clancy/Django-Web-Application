from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User


class SignUpForm(UserCreationForm):
    fname = forms.CharField(max_length=30, required=True)
    lname = forms.CharField(max_length=30, required=True)
    course = forms.CharField(max_length=30, required=True)
    email = forms.EmailField(max_length=254)

    class Meta:
        model = User
        fields = ('username', 'fname', 'lname', 'email', 'course', 'password1', 'password2', )



class addCourse(forms.Form):
    name = forms.CharField(label='Sudent Name', max_length=100)
    module = forms.CharField(label='Module Title', max_length=100)
